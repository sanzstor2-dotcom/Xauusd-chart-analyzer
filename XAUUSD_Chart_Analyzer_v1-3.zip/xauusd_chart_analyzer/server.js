import "dotenv/config";
import express from "express";
import multer from "multer";

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 }
});

app.use(express.static("public"));

app.post("/analyze", upload.single("chart"), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY belum diatur di server." });
    }
    if (!req.file) {
      return res.status(400).json({ error: "Silakan upload screenshot chart." });
    }

    const mime = req.file.mimetype || "image/png";
    const base64 = req.file.buffer.toString("base64");

    const prompt = `
Kamu adalah tutor analisis teknikal untuk pembelajaran, bukan penasihat keuangan.
Analisis screenshot chart yang diberikan secara visual.

Jelaskan dengan struktur:
1. Timeframe/simbol yang terlihat (jika terbaca; jangan menebak).
2. Struktur trend: bullish, bearish, atau sideways, beserta alasan visual.
3. Support dan resistance sebagai ZONA, bukan harga yang terlalu presisi.
4. RSI jika indikatornya terlihat. Jika tidak terlihat, katakan tidak terbaca.
5. MA jika terlihat: sebutkan periode jika tertulis dan hubungan harga dengan MA.
6. Candlestick/pola yang terlihat dan konteks lokasinya.
7. Hal yang masih tidak pasti atau kualitas screenshot yang membatasi analisis.

Jangan memberikan perintah BUY/SELL, entry, TP, SL, leverage, atau ukuran lot.
Jangan mengklaim bisa memprediksi harga dengan pasti.
Gunakan bahasa Indonesia yang sederhana.
`;

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-5.6-luna",
        input: [{
          role: "user",
          content: [
            { type: "input_text", text: prompt },
            {
              type: "input_image",
              image_url: `data:${mime};base64,${base64}`,
              detail: "high"
            }
          ]
        }]
      })
    });

    const data = await response.json();
    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || "API error"
      });
    }

    res.json({ analysis: data.output_text || "Tidak ada hasil analisis." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Terjadi kesalahan." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`XAUUSD Chart Analyzer berjalan di http://localhost:${port}`);
});
