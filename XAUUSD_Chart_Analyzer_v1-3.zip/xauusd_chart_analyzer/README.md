# XAUUSD Chart Analyzer

Versi pertama adalah alat analisis chart untuk pembelajaran. Ia membaca screenshot dan menjelaskan trend,
support/resistance, RSI, MA, candlestick, serta keterbatasan pembacaan gambar.

## Menjalankan

1. Install Node.js 18+.
2. Buka terminal di folder proyek.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Isi `OPENAI_API_KEY` pada `.env`. Jangan masukkan API key ke file HTML atau bagikan ke orang lain.
6. Jalankan `npm start`.
7. Buka `http://localhost:3000`.

Catatan: aplikasi sengaja tidak menghasilkan BUY/SELL, entry, TP, SL, leverage, atau ukuran lot.
